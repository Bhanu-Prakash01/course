import './firstpage.css'
import Courses from '../../components/courses/courses';
import React,{Component } from 'react';
import Navbar from '../../components/navbar/navbar';
import Faq from '../../components/faq/faq';
import Verybottom from '../../components/verybottom/verybottom';
import Footer from '../../components/footer/footer';
import Reviews from '../../components/reviews/reviews';
import axios from 'axios';
class Firstpage extends Component{
    // constructor()
    state={
        data:[],
        courses:[]
    };
    componentDidMount(){
        axios.get('/api/review/get')
        .then(res=>{
            this.setState({data:res.data})
        })
        axios.get('/api/course/get')
         .then(res=>{
             this.setState({courses:res.data})
         })
    }
    render() {
        return(
            <>
            <nav className="nav"><Navbar/></nav>
            <div className="courses">
                <h1 style={{color:'white',marginTop:-100}}>Courses</h1>
                <div className="cour">
                {this.state.courses.map(items=><Courses data={items}/>)}
                </div>
            </div>
            <div className="review">
            <h1 style={{color:'white',marginTop:10}}>Reviews</h1>
                <div className="rev">
                    {this.state.data.map(items=><Reviews data={items}/>)}
                </div>
            </div>
            <div className="faq">
            <h1 style={{color:'white',marginTop:10}}>FAQ</h1>
                <div className="f">
                    <Faq/>
                    <Faq/>
                    <Faq/>
                    <Faq/>
                    <Faq/>
                    <Faq/>
                </div>
            </div>
            <div className="footer">
                <div className="fo">
                    <Footer/>
                </div>
            </div>
            <Verybottom/>
            </>
        )
    }
}

export default Firstpage;