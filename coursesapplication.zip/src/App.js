import Secondpage from './pages/secondpage/secondpage'
import Firstpage from './pages/firstpage/firstpage';
import {BrowserRouter as Router, Switch, Route} from "react-router-dom";
import './App.css';
function App(){
  return(
    <div className='app'>
      <Router>
        <Switch>
          <Route exact path='/' component={Firstpage}/>
          <Route exact path='/:courseId' component={Secondpage}/>
        </Switch>
      </Router>
    </div>
  )
}
export default App;