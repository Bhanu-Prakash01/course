import './verybottom.css';
function Verybottom(){
    return(
        <>
        <div className="footer-copy">
            <div className="social_media_copy">
                <span className="followsheading">FOLLOW US</span>
                <span className="followusicons"><i class="fab fa-twitter"></i></span>
                <span className="followusicons"><i class="fab fa-facebook-f"></i></span>
                <span className="followusicons"><i class="fab fa-linkedin"></i></span>
                <span className="followusicons"><i class="fab fa-github-square"></i></span>
                <span className="followusicons"><i class="fab fa-youtube"></i></span>
                <span className="followusicons"><i class="fab fa-instagram"></i></span>
            </div>
            <div className="copy-right">
                <span className="cpyname">© 2021 by ABC</span>
            </div>
        </div>
        </>
    )
}
export default Verybottom;