import './submit.css';
import { useParams } from 'react-router';
import React,{useState} from 'react';
import axios from 'axios';

function Submit(){
    const params=useParams();
    const [url,setUrl]=useState('')
    const [firstname,setFirstName]=useState('');
    const [lastname,setLastName]=useState('');
    const [email,setEmail]=useState('');
    const [phonenumber,setPhoneNumber]=useState('');
    const [password,setPassword]=useState('');
    const nameofthecourse=params.courseId
    function  submithandler(e){
        e.preventDefault();
        const submit_data={firstname,lastname,email,phonenumber,password,nameofthecourse};
        fetch('/api/user/post',{
            method:'POST',
            headers:{"Content-Type": "application/json"},
            body:JSON.stringify(submit_data)
        }).then((res)=>console.log(res))
    }
    return(
        <>
          <div className="submit-box">
            <div className="submit-right-box">
                <div className="submit-course-details-view">
                    <label className="submit-course-heading">MERN STACK DEVLOPMENT</label> 
                    <p className="submit-course-detialed-text">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Vel fuga, dolores perferendis ex maiores tempora cupiditate, odit perspiciatis esse minima fugit illo tempore! Eaque sed dignissimos ratione, est porro deleniti harum, officia distinctio expedita tempore eligendi iste. Quos consequuntur unde quam laudantium dolores veniam quisquam vel magnam dolorum eaque. Quod.</p>
                </div>
            </div>  
            <div className="submit-left-box">
                <div className="submit-form-box">
                    <label  className="label-form-heading"> Join Now</label>
                    <form className='submit-form' onSubmit={submithandler}>
                        <label  className="submit-form-input-header">First Name</label>
                        <input type="text" className="submit-from-text-entry"value={firstname} onChange={(e)=>setFirstName(e.target.value)}/>
                        <label  className="submit-form-input-header" >Last Name</label>
                        <input type="text" className="submit-from-text-entry" value={lastname} onChange={(e)=>setLastName(e.target.value)} />
                        <label  className="submit-form-input-header">Email</label>
                        <input type="text" className="submit-from-text-entry" value={email} onChange={(e)=>setEmail(e.target.value)} />
                        <label  className="submit-form-input-header">Phone Number</label>
                        <input type="text" className="submit-from-text-entry" value={phonenumber} onChange={(e)=>setPhoneNumber(e.target.value)} />
                        <label  className="submit-form-input-header">Password</label>
                        <input type="password" className="submit-from-text-entry" value={password} onChange={(e)=>setPassword(e.target.value)} />
                        <button className="submit-form-btn" >Apply Now</button>
                    </form>
                </div>
            </div>
          </div>  
        </>
    )
}
export default Submit;