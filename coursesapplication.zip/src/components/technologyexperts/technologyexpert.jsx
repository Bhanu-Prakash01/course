import './technologyexpert.css';
function Technologyexpert(){
    return(
        <>
        <div className="technologybox">
            <div className="technoexpertstextbox">
                <p className="technoexpertstext">Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus aliquid magni tempora eum ipsam quae, adipisci obcaecati inventore facilis ratione ad, iusto ut reiciendis quia sunt libero. Placeat, deserunt delectus?</p>
            </div>
            <div className="coach-boxes">
                <div className="technobottombox">
                    <div className="technoboxdetail">
                        <img src="https://www.xebiaacademyglobal.com/careerpro_style/assets/images/amarjeet-trainer.jpg" alt="" className="technoimgview" />
                    </div>
                    <div className="technouserdetail">
                        <span className="coachname">John Doe</span>
                        <span className="coachexpertin">Full stack devolper</span>
                    </div>
                </div>
                <div className="technobottombox">
                    <div className="technoboxdetail">
                        <img src="https://www.xebiaacademyglobal.com/careerpro_style/assets/images/amarjeet-trainer.jpg" alt="" className="technoimgview" />
                    </div>
                    <div className="technouserdetail">
                        <span className="coachname">John Doe</span>
                        <span className="coachexpertin">Full stack devolper</span>
                    </div>
                </div>
                <div className="technobottombox">
                    <div className="technoboxdetail">
                        <img src="https://www.xebiaacademyglobal.com/careerpro_style/assets/images/amarjeet-trainer.jpg" alt="" className="technoimgview" />
                    </div>
                    <div className="technouserdetail">
                        <span className="coachname">John Doe</span>
                        <span className="coachexpertin">Full stack devolper</span>
                    </div>
                </div>
            </div>
        </div>
        </>
    )
}
export default Technologyexpert;