import './footer.css';
function Footer(){
    return(
        <>
            <div className="footer_box"> 
                <div className="footer_aboutus">
                    <span className="footer_header">ABOUT US</span>
                    <span className="footer_companyname_heading">COMPANY NAME</span>
                    <span className="footer_company_name">web info</span>
                    <span className="footer_companyname_heading">Email Address</span>
                    <span className="footer_company_name">abc@gamil.com</span>
                </div>
                <div className="footer_social_media">
                <span className="footer_header">SOCIAL MEDIA</span>
                <a href="https://wa.me/9515000318" class="whatsapp_footer" target="_blank"> <i class="fab fa-whatsapp"></i> Whats app</a>
                <a href="mailto:kingkite44@gmail.com" class="email_footer" target="_blank"><i class="fas fa-envelope"></i> Email</a>
                </div>
                <div className="footer_contactus">
                <span className="footer_header">CONTACT US</span>
                    <span className="footer_phone">Mobile Number</span>
                    <span className="footer_phone_number">+91 789456123</span>
                    <span className="footer_phone">E-mail</span>
                    <span className="footer_phone_number">abc@gmail.com</span>
                </div>
            </div>
        </>
    )
}
export default Footer;