import './reviews.css';
import Aos from 'aos';
import React,{useEffect} from 'react';
import 'aos/dist/aos.css';

function Reviewboxer({props}){
    return(
        <>
        <div className="review-identity" >
            <p className="reviewername">{props.name}</p>
            <span className="review-rating">{props.rating}</span>
        </div>
        <div className="review-text-box"><p className="review-text">{props.review}</p></div>
        </>
    )
}

function Reviews({data}){
    var animations = ["fade-left","fade-right"];
    var animation = animations[Math.floor(Math.random() * animations.length)];
    useEffect(()=>{
        Aos.init({duration:2000});
    })
    return(
        <>
        <div className="review-box" data-aos={animation}>
            <Reviewboxer props={data}/>
        </div>
        </>
    )
}
export default Reviews;