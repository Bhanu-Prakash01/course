const mongoose=require('mongoose');

const ReviewSchema=new mongoose.Schema({
    Name:{
        type:String
    },
    rating:{
        type:Number
    },
    review:{
        type:String
    }

})
module.exports=mongoose.model("REVIEW",ReviewSchema);