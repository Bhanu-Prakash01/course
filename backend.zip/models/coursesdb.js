const mongoose=require('mongoose');

const CourseSchema=new mongoose.Schema({
    coursename:{
        type:String,
        require:true
    },
    typeofthecourse:{
        type:String,
        require:true
    },
    timetakenbythecourse:{
        type:String,
        require:true
    },
    coursedetail:{
        type:String,
        require: true
    },
    costofthecourse:{
        type:String,
        require: true
    }
});
module.exports=mongoose.model("COURSES",CourseSchema);