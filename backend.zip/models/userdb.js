const mongoose=require('mongoose');

const UserSchema=new mongoose.Schema({
    firstname:{
        type:String,
        require:true
    },
    lastname:{
        type:String,
        require:true
    },
    email:{
        type:String,
        require:true
    },
    phonenumber:{
        type:String,
        require: true
    },
    password:{
        type:String,
        require: true
    },
    nameofthecourse:{
        type:String,
        require: true
    }
});

module.exports=mongoose.model("USERS",UserSchema);