const router= require('express').Router();
const Course =require('../models/coursesdb')

//create course
router.post('/post', async (req,res)=>{
    const  course = await new  Course({
        coursename:req.body.coursename,
        typeofthecourse:req.body.typeofthecourse,
        timetakenbythecourse:req.timetakenbythecourse,
        // timetakenbythecourse: req.body.timetakenbythecourse,
        // timetakenbythecourse: req.body.timetakenbythecourse,
        coursedetail: req.body.coursedetail,
        costofthecourse: req.body.costofthecourse,
    });
    try{
        const coursedata= await course.save();
        res.status(201).send(coursedata)
    }catch(err){
        console.log(err)
    }
})

//get course
router.get('/get', async (req,res)=>{
    const course_data= await Course.find();
    res.send(course_data)
})

module.exports=router