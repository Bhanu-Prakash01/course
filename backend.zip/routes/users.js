const router= require('express').Router();
const User = require('../models/userdb');
const Courses= require('./courses')


router.post('/post', async (req,res)=>{
    // const nameofcourse=Courses.find({_id:req.body.nameofthecourse})
    // const coursename=await Courses.find()
    const user = await new User({
        firstname:req.body.firstname,
        lastname:req.body.lastname,
        email:req.body.email,
        phonenumber: req.body.phonenumber,
        password: req.body.password,
        nameofthecourse: req.body.nameofthecourse
    });
    try{
        const userdata= await user.save();
        res.status(201).send(userdata)
    }catch(err){
        console.log(err)
    }
})
router.get('/get', async (req,res)=>{
    const user_data= await User.find();
    res.send(user_data)
})

module.exports=router;  