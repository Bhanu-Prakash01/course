const router= require('express').Router();
const Review= require('../models/reviewdb');

router.post('/post', async (req,res)=>{
    const review = await new Review({
        Name: req.body.name,
        rating: req.body.rating,
        review: req.body.review
    })
    review_saved=await review.save();
    res.status(201).send(review_saved)
})
router.get('/get',async (req,res)=>{
    const review=await Review.find()
     .skip(10)
     .limit(10);
    res.status(200).send(review)
})
module.exports=router;  