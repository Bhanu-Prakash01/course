const mongoose=require('mongoose')
const express=require('express');
const helmet = require('helmet');
const app=express();
require('dotenv').config();
const review=require('./routes/review');
const userroute=require('./routes/users');
const coursesroute=require('./routes/courses');

mongoose.connect(process.env.MONGODB).then(()=>console.log('connected ')).catch(()=>console.log('db connection is failed'))

//middleware
app.use(express.json());
app.use(helmet());
var cors = require('cors');
app.use(cors());
app.use('/api/user',userroute)
app.use('/api/course',coursesroute)
app.use('/api/review',review)

app.listen(8000,()=>{
    console.log('server running on port number 5000' )
})